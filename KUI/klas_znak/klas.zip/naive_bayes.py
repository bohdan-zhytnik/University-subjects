import argparse
import os
from PIL import Image
import numpy as np

NUM_SHADES = 16
PNG_SIZE_BUFF = 30

def setup_arg_parser():
    parser = argparse.ArgumentParser(description='Learn and classify image data.')
    parser.add_argument('train_path', type=str, help='path to the training data directory')
    parser.add_argument('test_path', type=str, help='path to the testing data directory')
    parser.add_argument("-o", metavar='filepath', 
                        default='classification.dsv',
                        help="path (including the filename) of the output .dsv file with the results")
    return parser

def find_dsv(listdir_array):
    for i in range(len(listdir_array)):
        if listdir_array[i].endswith('.dsv'):
            return i
    return -1

def read_dvs_file(file_path):
    data_dict = {}
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            parts = line.split(':') 
            data_dict[parts[0]] = parts[1]
    return data_dict

def make_train_data_dict(file_names, train_path):
    train_data_dict = {}
    for img in file_names:
        train_data_dict[img] = np.array(Image.open(f"{train_path}/{img}")).astype(int).flatten() // NUM_SHADES
        # print(train_data_dict[img], end='\n')
    return train_data_dict

def write_to_dvs(classificated_data, path_o):
    with open(path_o, 'w') as file:
        for img in classificated_data.keys():
            file.write(f"{img}:{classificated_data[img]}\n")

def analysis(train_data_dict, train_data_dvs):
    img_num = len(list(train_data_dvs.values()))

    class_count = {}
    class_by_pixel = {}
    for img in train_data_dict.keys():
        if train_data_dvs[img] not in class_count:
            class_count[train_data_dvs[img]] = 0
            class_by_pixel[train_data_dvs[img]] = np.zeros((PNG_SIZE_BUFF ** 2, NUM_SHADES))

        class_count[train_data_dvs[img]] +=1
        for i in range(len(list(train_data_dict[img]))):
            class_by_pixel[train_data_dvs[img]][i][list(train_data_dict[img])[i]] +=1
        
    prob_count = {}
    prob_by_pixel = {}

    for i in class_count.keys():
        prob_count[i] = class_count[i] / img_num

        prob_by_pixel[i] = (class_by_pixel[i]+1) / (img_num + NUM_SHADES*1)

    return prob_count, prob_by_pixel
            
def classification (prob_count, prob_by_pixel, test_data):
    classified_data={}
    for img in test_data.keys():
        max_prob = float("-inf")
        max_class = ''
        for i in prob_count.keys():
            prob = np.log(prob_count[i])
            for idx in range(len(list(test_data[img]))):
                prob+=np.log(prob_by_pixel[i][idx][list(test_data[img])[idx]])
            if prob > max_prob:
                max_prob = prob
                max_class = i
        classified_data[img] = max_class
    return classified_data




def main():
    parser = setup_arg_parser()
    args = parser.parse_args()
    
    print('Training data directory:', args.train_path)
    print('Testing data directory:', args.test_path)
    print('Output file:', args.o)
    print("Running Naive Bayes classifier")
    
    train_data = os.listdir(args.train_path)
    test_data = os.listdir(args.test_path)
    dsv_idx = find_dsv(train_data)
    train_data_dvs = read_dvs_file(f"{args.train_path}/{train_data[dsv_idx]}")

    if dsv_idx > 0:
        train_data.remove(train_data[dsv_idx])

    file_names = train_data_dvs.keys()
    train_data_dict = make_train_data_dict(file_names ,args.train_path)
    test_data_dict = make_train_data_dict(test_data, args.test_path)

    prob_count, prob_by_pixel = analysis(train_data_dict, train_data_dvs)
    classified_data = classification (prob_count, prob_by_pixel, test_data_dict)
    write_to_dvs(classified_data, args.o)



if __name__ == "__main__":
    main()

