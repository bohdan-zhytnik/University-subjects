import argparse
import os
from PIL import Image
import numpy as np
from collections import Counter


def setup_arg_parser():
    parser = argparse.ArgumentParser(description='Learn and classify image data.')
    parser.add_argument('train_path', type=str, help='path to the training data directory')
    parser.add_argument('test_path', type=str, help='path to the testing data directory')
    parser.add_argument('-k', type=int, 
                        help='run k-NN classifier (if k is 0 the code may decide about proper K by itself')
    parser.add_argument("-o", metavar='filepath', 
                        default='classification.dsv',
                        help="path (including the filename) of the output .dsv file with the results")
    return parser


def find_dsv(listdir_array):
    for i in range(len(listdir_array)):
        if listdir_array[i].endswith('.dsv'):
            return i
    return -1

def read_dvs_file(file_path):
    data_dict = {}
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            parts = line.split(':') 
            data_dict[parts[0]] = parts[1]
    return data_dict

def make_train_data_dict(file_names, train_path):
    train_data_dict = {}
    for img in file_names:
        train_data_dict[img] = np.array(Image.open(f"{train_path}/{img}")).astype(int).flatten()
        # print(train_data_dict[img], end='\n')
    return train_data_dict

def get_dist(img1, img2):
    diff = img1 - img2
    dist = np.sqrt(np.sum(np.square(diff)))
    return dist

def classification(train_data_dict, test_data_dict, train_data_dvs, test_path, k):
    classified_data={}
    for img in test_data_dict.keys():
        img_dist_arr = []

        for img_train in train_data_dict.keys():
            dist = get_dist(test_data_dict[img], train_data_dict[img_train])
            img_dist_arr.append(dist)
        
        dist_arr = np.array(img_dist_arr)
        # print(dist_arr)
        train_img_idx = np.argpartition(dist_arr, k, axis=0)[:k]
        
        # print()
        # print(train_img_idx)

        dvs_values_no_np = []
        for i in train_img_idx:
            dvs_values_no_np.append(list(train_data_dvs.values())[i])
        # print(dvs_values_no_np)
        # dvs_values = np.array(dvs_values_no_np)
        # print(dvs_values)
        # most_common_value = np.argmax(np.bincount(dvs_values))

        counter = Counter(dvs_values_no_np)
        most_common_value, count = counter.most_common(1)[0]
        # print(most_common_value)
        classified_data[img] = most_common_value
        # break
        # classes = np.array(list(known_data.values()))
    return classified_data



def write_to_dvs(classificated_data, path_o):
    with open(path_o, 'w') as file:
        for img in classificated_data.keys():
            file.write(f"{img}:{classificated_data[img]}\n")

def main():
    parser = setup_arg_parser()
    args = parser.parse_args()
    
    print('Training data directory:', args.train_path)
    print('Testing data directory:', args.test_path)
    print('Output file:', args.o)
    
    print(f"Running k-NN classifier with k={args.k}")

    train_data = os.listdir(args.train_path)
    test_data = os.listdir(args.test_path)
    dsv_idx = find_dsv(train_data)
    
    # if dsv_idx > 0:
    #     train_data.remove(train_data[dsv_idx])

    train_data_dvs = read_dvs_file(f"{args.train_path}/{train_data[dsv_idx]}")

    if dsv_idx > 0:
        train_data.remove(train_data[dsv_idx])


    file_names = train_data_dvs.keys()
    # print(test_data)
    # print()
    # print(file_names)
    train_data_dict = make_train_data_dict(file_names ,args.train_path)
    test_data_dict = make_train_data_dict(test_data, args.test_path)
    # print(test_data_dict)

    classified_data = classification(train_data_dict, test_data_dict, train_data_dvs, args.test_path, args.k)
    # print(classified_data)
    write_to_dvs(classified_data, args.o)
    return 0
        
        
if __name__ == "__main__":
    main()
    
