#ifndef HEADER
#define HEADER

static int heade_arr[79000];

static  int heade_arr_len = 78498;

#endif
