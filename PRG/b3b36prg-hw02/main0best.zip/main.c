#include <stdio.h>
#include <stdlib.h>
// #include <stdbool.h>

#include "my_header_file.h"

#define INPUT_OK EXIT_SUCCESS
#define ERROR_INPUT 100
#define TRUE 1
#define FALSE 0
#define INDENT  " x "
#define NO_SPACE "''"

long long int read_input(void);
void prime_factorization(long long int n);
void print_number_with_power(int count, int p_n_i, char* indent);
int prime_number_control(long long int n);
/* The main program */
int main(int argc, char *argv[])
{
  int ret=INPUT_OK;
  long long int  n;
  // scanf("%llu",&n);
  while((n=read_input())>0){
  // while(n>0){
    // printf("%llu\n",n);
    if (n==1){
      printf("Prvociselny rozklad cisla %lld je:\n",n);
      printf("%d\n",1);
    }else if(prime_number_control(n)==TRUE){
      printf("Prvociselny rozklad cisla %lld je:\n",n);
      printf("%lld\n",n);
    }else{
    printf("Prvociselny rozklad cisla %lld je:\n",n);
            // printf("%d\n",arr_len);
    prime_factorization(n);
    }
  }
  if (n<0){
    fprintf(stderr,"Error: Chybny vstup!\n");
    ret=ERROR_INPUT;
  }
  return ret;
}


long long int read_input(void){
  long long int  n = -1;
  // int control=1;
  if (scanf("%lld",&n) != 1){
    n=-1;
  }
  // printf("%llu\n",n);
  return n;
}


void prime_factorization(long long int n){
  int p_n_i=0;
  
  // prime_number_index
  // int prime_number_index =0;
  int count = 0 ;
  // count_divisions
  long long int n_for_loop = n;
  int multiple = FALSE;
  // printf("\nin if=%d,%d\n",arr[p_n_i],count);
  while(arr[p_n_i] <= n_for_loop){
          // printf("arr[p_n_i]=%d\n",arr[p_n_i]);
    if((n%arr[p_n_i]) == 0 && n !=1){
      n=n/arr[p_n_i];
      count+=1;
          // printf("count=%d\n",count);
          // int a = 3/3;
          // printf("delenie%d\n",a);
          // printf("\nin if=%d,%d\n",arr[p_n_i],count);




    
    }else{
      // printf("in else=%d,%d\n",arr[p_n_i],count);
      if(multiple==TRUE){
      // char indetn[] = INDENT;
            // printf("multiple=%d\n",multiple);
        if (count >0 && count != 1 ){
          printf(" x %d^%d",arr[p_n_i],count);
          count=0;
          // multiple = true;
        }if (count == 1 ) {
          printf(" x %d",arr[p_n_i]);
          count=0;
          // multiple = true;
        }
        // print_number_with_power(count, p_n_i, indetn );
        // count=0;
        // p_n_i++;
      }


      if(multiple==FALSE){
        if (count >0 && count != 1 ){
          printf("%d^%d",arr[p_n_i],count);
          count=0;
          multiple = TRUE;
        }if (count == 1 ) {
          printf("%d",arr[p_n_i]);
          count=0;
          multiple = TRUE;
        }
        // count=0;
      // multiple = TRUE;
        // p_n_i++;
      }
      p_n_i++;
      if (n==1){
        break;
      }
    } 
    // if (n==1){
    //   break;
    // }
  }
  printf("\n");

}


int prime_number_control(long long int n){

    for(int i = 0; i < arr_len; i++) {
      if(arr[i] == n) {
        return TRUE;
      }
    }
    return FALSE;
}

