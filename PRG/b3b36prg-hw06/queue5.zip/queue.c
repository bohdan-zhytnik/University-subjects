#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "queue.h"

// typedef struct {
//       void **array;
//       int head;
//       int tail;
//       int size;
//       int capacity;
// } queue_t;  

queue_t* create_queue(int capacity);
void delete_queue(queue_t *queue);
bool push_to_queue(queue_t *queue, void *data);
void* pop_from_queue(queue_t *queue);
void* get_from_queue(queue_t *queue, int idx);
int get_queue_size(queue_t *queue);



queue_t* create_queue(int capacity){
    queue_t *queue=malloc(sizeof(queue_t));
    queue->array=malloc(capacity*sizeof(void*));
    queue->head=0;
    queue->tail=0;
    queue->size = 0;
    queue->capacity=capacity;
    return queue;
}

/* deletes the queue and all allocated memory */
void delete_queue(queue_t *queue){
    free(queue->array);
    free(queue);

}

/*
 * inserts a reference to the element into the queue
 * returns: true on success; false otherwise
 */
bool push_to_queue(queue_t *queue, void *data){
    if (data==NULL){
        return false;
    }
    if ((queue->capacity)==queue->size){
        int old_capacity=queue->capacity;
        queue->capacity*=2;
        void **new_array=malloc(queue->capacity*(sizeof(void*)));
        if (new_array==NULL){
            return false;
        } 
        for (int i=0; i < queue->size; i++){
            new_array[i]=queue->array[((queue->head+i) % old_capacity)];
        }
        free(queue->array);
        queue->array=new_array;
        queue->head=0;
        queue->tail=queue->size;
    }
    if ((queue->capacity)==queue->size) {
        return false;
    }

    queue->array[queue->tail]=data;
    queue->tail=(queue->tail+1)%queue->capacity;
    queue->size++;
    return true;
}

/*
 * gets the first element from the queue and removes it from the queue
 * returns: the first element on success; NULL otherwise
 */
void* pop_from_queue(queue_t *queue){
    if (queue->size==0){
        return NULL;
    }
    void *value=queue->array[queue->head];
    queue->head=(queue->head+1)%queue->capacity;
    queue->size--;
    if (queue->size > 0 && queue->size < ((queue->capacity/3)*2)-1){
        int old_capacity=queue->capacity;
        queue->capacity=((queue->capacity/3)*2)+1;
        void **new_array=malloc(queue->capacity*(sizeof(void*)));
        if (new_array==NULL){
            return NULL;
        } 
        for (int i=0; i < queue->size; i++){
            new_array[i]=queue->array[((queue->head+i) % old_capacity)];
        }
        free(queue->array);
        queue->array=new_array;
        queue->head=0;
        queue->tail=queue->size; 
    }
    return value;
}

/*
 * gets idx-th element from the queue, i.e., it returns the element that 
 * will be popped after idx calls of the pop_from_queue()
 * returns: the idx-th element on success; NULL otherwise
 */
void* get_from_queue(queue_t *queue, int idx){
    // void *value = NULL;
    // if (queue->array[((queue->head+idx)%queue->capacity)]==NULL || idx >= queue->size){
    //     return NULL;
    // }
    // value = queue->array[(queue->head+idx)%queue->capacity];

    // return value;

    void *value = NULL;
    if (idx < 0 || idx >= queue->size){
        return NULL;
    }
    value = queue->array[(queue->head+idx)%queue->capacity];

    return value;


}

/* gets number of stored elements */
int get_queue_size(queue_t *queue){
    return queue->size;
}

