#include <stdio.h>
#include <stdlib.h>

// #define DASH '-'
// #define DASH '?'
// #define DASH '*'
// #define PLUS '+'
size_t my_strlen(char *);
int symbol_search(char *, char symbol);
int str_search(char *,char[],int len_str);
int text_search(char *,char[],int len_str);
void get_str_before_symbol(char[],char symbol,char *sign_before_r_e, char[]);
/* The main program */
int main(int argc, char *argv[])
{
  char *pattern = NULL;
  int len_pattern=0;
  FILE *file;
  char *filename = NULL;
  int option=0;                       //sign describing an optional task
  char regular_expression[4]={'?','*','+'};
  int number_r_e=0;                    // sign number in regular expression
  char sign_before_r_e;
  char str_before_r_e[64];              



  char E[3] = "-E";
  char clor[15] = "--color=always";
  int len_E=2;
  int len_color=14;

  // printf("%s\n",argv[1]);
  for(int i=1; i<argc; i++){
    // ret += symbol_search(argv[i], '-');
    if (argv[i][0] == '-'){
      // printf("%c\n",argv[0]);
      option += str_search(argv[i], E, len_E);
      if (str_search(argv[i], clor, len_color))
      {
        option += 2;
      }
    }
    else if (symbol_search(argv[i], '.')){
      filename=argv[i];
    }
    else{
      for (int j=0; j<4; j++){
        if(symbol_search(argv[i], regular_expression[j])){
          if(regular_expression[j]=='?'){
            number_r_e=1;
          }else if (regular_expression[j]=='*'){
            number_r_e=2;
          }else{
            number_r_e=3;
          }
          get_str_before_symbol(argv[i], regular_expression[j], &sign_before_r_e, str_before_r_e);
        }
      }
      pattern=argv[i];
      len_pattern=my_strlen(pattern);
    }
  }
  if (filename==NULL){
    // option+=4;
    // printf("A\n");
  }
  // printf("\033[0;31mHello, hello\033[0m\n");
  // printf("\033[01;31mHello, hello\033[K\033[m\n");
  // printf("\033[01;31m\033[KHello, hello\033[m\033[K\n");
  // printf("H\033[01;31m\033[Kel\033[m\033[Klo, ");
  // printf("h\033[01;31m\033[Kel\033[m\033[Klo\n");

  // printf("len_pattern  %d\n",len_pattern);
  // printf("sign_before_r_e  %c\n",sign_before_r_e);
  // printf("str_before_r_e:   %s\n", str_before_r_e);
  // printf("number_r_e  %d\n",number_r_e);
  // printf("filename:   %s\n", filename);
  // printf("pattern:   %s\n", pattern);
  // printf("%d\n", option);
  char line[128];
  file = fopen(filename, "r");
  if (file == NULL) {
    // fprintf(stderr, "Не удалось открыть файл %s\n", filename);
    return 1;
  }
      int control=number_r_e;
  control=1;
  while (fgets(line, sizeof(line), file) != NULL) {
    // printf("if");
    if (text_search(line, pattern, len_pattern)){
      printf("%s",line);
      control=0;
    }
  }
    // Закрываем файл
    fclose(file);

  return control;
}

size_t my_strlen(char *str) {
    size_t length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

int symbol_search(char *argv, char symbol){
  for(int i = 0; argv[i] != '\0'; i++){
    if (argv[i]==symbol){
      return 1;
    }
  }
  return 0;
}



int str_search(char *argv, char str[],int len_str){
  int count=0;
  // printf("%s\n",argv);
  // printf("%sSTR\n",str);
  // printf("LA  %d\n",len_str);
  for (int i = 0; str[i] != '\0'; i++){
    // printf("%c  %c\n",argv[i],str[i]);
    if (argv[i]==str[i]){
      count++;
      // printf("%c  %c\n",argv[i],str[i]);
      // printf("%d,%s\n",count, str);
    }
    // else{
    //   return 0;
    // }

    if(count==len_str){
      return 1;
    }
  
  }
  return 0;
}

int text_search(char *argv, char str[],int len_str){
  int count=0;
  // printf("%s",argv);
  for (int i=0; argv[i] != '\0'; i++){
    if (argv[i]==str[count]){
      // count++;
    
    // printf("yes\n");
      // int i_for_while=i;
      // while(argv[i_for_while]==str[count]){
      // printf("yes\n");
      // for(int j=1; i<len_str; j++){
      //   int i_for_loop=i+1;
      //   if (argv[i_for_loop])
        // if (i_for_while<)
        // i_for_while++;
        count++;
        if (count==len_str){
          return 1;
        }
      
      // count=0;
      
    }else{
      count=0;
    }
  }
  return 0;

}

void get_str_before_symbol(char *argv,char symbol,char *sign,char *str){
  char front_char;
  for (int i=0; argv[i]!='\0';i++){
    if (argv[i]!=symbol){
      if (i!=0){
        str[i-1]=front_char;
      }
      front_char=argv[i];
    }
    if (argv[i]==symbol){
      *sign=front_char;
    }
  }

}



