"""Module for path planning algorithms."""
